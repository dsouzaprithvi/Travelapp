package com.example.vagabondapp.adpters;

public class Recentchatadapter {
}
