package com.example.vagabondapp.models;

public class TranscationModel {

    String amount, id, note, type, date;

    public TranscationModel() {
    }

    public TranscationModel(String amount, String id, String note, String type, String date) {
        this.amount = amount;
        this.id = id;
        this.note = note;
        this.type = type;
        this.date = date;
    }

    public TranscationModel(String amount, String note, String type, String date) {
        this.amount = amount;
        this.note = note;
        this.type = type;
        this.date = date;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
