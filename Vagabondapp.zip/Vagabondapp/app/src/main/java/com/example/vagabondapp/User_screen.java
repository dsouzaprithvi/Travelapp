package com.example.vagabondapp;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.example.vagabondapp.adpters.UsersAdapter;
import com.example.vagabondapp.models.Users;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class User_screen extends AppCompatActivity {

    MaterialButton back;

    FirebaseAuth auth;
    FirebaseDatabase database;

    ArrayList<Users> usersholder;
    UsersAdapter adapter;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_screen);


        back = findViewById(R.id.back);
        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        usersholder = new ArrayList<>();
        adapter = new UsersAdapter(this, usersholder);
        recyclerView.setAdapter(adapter);

        loaddata();

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void loaddata () {

        String id = auth.getCurrentUser().getUid();

        database.getReference().child("Users").
                addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        usersholder.clear();
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Users obj = dataSnapshot.getValue(Users.class);
                            usersholder.add(obj);



                        }
                        Collections.sort(usersholder, new Comparator<Users>() {
                            @Override
                            public int compare(Users users, Users t1) {
                                return users.getUsername().compareToIgnoreCase(t1.getUsername());
                            }
                        });

                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}