package com.example.vagabondapp.models;

public class Recentchatmodel {

}
