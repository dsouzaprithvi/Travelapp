package com.example.vagabondapp.fragments;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationRequest;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.example.vagabondapp.MainActivity;
import com.example.vagabondapp.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.util.List;


public class SuggestionFragment extends Fragment {


    CardView cardmalls, cardreligious, cardrestaurants, cardbeach, cardhotels, cardpark;
    FusedLocationProviderClient client;

    protected LocationManager locationManager;
    protected LocationListener locationListener;
    protected Context context;
    TextView txtLat;
    String lat;
    String provider;
    protected String latitude, longitude;
    protected boolean gps_enabled, network_enabled;
    int count = 10;
    double latt;
    double longi;

    public SuggestionFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_suggestion, container, false);

        cardmalls = view.findViewById(R.id.card_malls);
        cardbeach = view.findViewById(R.id.card_beach);
        cardreligious = view.findViewById(R.id.card_religious);
        cardhotels = view.findViewById(R.id.card_hotels);
        cardpark = view.findViewById(R.id.card_park);
        cardrestaurants = view.findViewById(R.id.card_restaurants);



        client = LocationServices.getFusedLocationProviderClient(getActivity());

        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            getCurrentLocation();
        }

        cardmalls.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String loc = String.valueOf(latt) + "," + String.valueOf(longi);
                Uri uri = Uri.parse("https://www.google.com/maps/search/malls+near+me+/@" + loc + ",15z/data=!3m1!4b1");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                intent.setPackage("com.google.android.apps.maps");
                getActivity().startActivity(intent);
            }
        });

        cardrestaurants.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String loc = String.valueOf(latt) + "," + String.valueOf(longi);
                Uri uri = Uri.parse("https://www.google.com/maps/search/restaurants+near+me+/@" + loc + ",15z/data=!3m1!4b1");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                intent.setPackage("com.google.android.apps.maps");
                getActivity().startActivity(intent);
            }
        });

        cardhotels.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String loc = String.valueOf(latt) + "," + String.valueOf(longi);
                Uri uri = Uri.parse("https://www.google.com/maps/search/hotels+near+me+/@" + loc + ",15z/data=!3m1!4b1");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                intent.setPackage("com.google.android.apps.maps");
                getActivity().startActivity(intent);
            }
        });

        cardpark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String loc = String.valueOf(latt) + "," + String.valueOf(longi);
                Uri uri = Uri.parse("https://www.google.com/maps/search/parks+near+me+/@" + loc + ",15z/data=!3m1!4b1");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                intent.setPackage("com.google.android.apps.maps");
                getActivity().startActivity(intent);
            }
        });

        cardbeach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String loc = String.valueOf(latt) + "," + String.valueOf(longi);
                Uri uri = Uri.parse("https://www.google.com/maps/search/beaches+near+me+/@" + loc + ",15z/data=!3m1!4b1");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                intent.setPackage("com.google.android.apps.maps");
                getActivity().startActivity(intent);
            }
        });

        cardreligious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String loc = String.valueOf(latt) + "," + String.valueOf(longi);
                Uri uri = Uri.parse("https://www.google.com/maps/search/religious+places+near+me+/@" + loc + ",15z/data=!3m1!4b1");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                intent.setPackage("com.google.android.apps.maps");
                getActivity().startActivity(intent);
            }
        });




//        12.876521,74.848320
        return view;
    }


    @SuppressLint("MissingPermission")
    private void getCurrentLocation() {
        // Initialize Location manager
        LocationManager locationManager
                = (LocationManager) getActivity()
                .getSystemService(
                        Context.LOCATION_SERVICE);
        // Check condition
        if (locationManager.isProviderEnabled(
                LocationManager.GPS_PROVIDER)
                || locationManager.isProviderEnabled(
                LocationManager.NETWORK_PROVIDER)) {
            // When location service is enabled
            // Get last location
            client.getLastLocation().addOnCompleteListener(new OnCompleteListener<Location>() {
                @Override
                public void onComplete(@NonNull Task<Location> task) {
                    Location location = task.getResult();
                    // Check condition
                    if (location != null) {
                        // When location result is not
                        // null set latitude
                        String.valueOf(location.getLatitude());
                        // set longitude
                        String.valueOf(location.getLongitude());
                    }
                }
            });

        }
    }
}