package com.example.vagabondapp;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.vagabondapp.models.Users;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class Getaadharcard extends AppCompatActivity {

    ImageView aadharimage;
    Button chooseimage, update;
    ProgressDialog progressDialog;

    FirebaseAuth auth;
    FirebaseDatabase database;
    FirebaseStorage storage;

    ActivityResultLauncher mTakePhoto;
    Uri selectedImageUri;
    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_getaadharcard);

        aadharimage = findViewById(R.id.aadharimage);
        chooseimage = findViewById(R.id.chooseimage);
        update = findViewById(R.id.update);

        progressDialog = new ProgressDialog(Getaadharcard.this);
        progressDialog.setTitle("Updating Details");

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();

        mTakePhoto = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            if (result.getData() != null ) {
                                Bundle extras = result.getData().getExtras();
                                if (extras != null) {
                                    bitmap = (Bitmap) extras.get("data");
                                    aadharimage.setImageBitmap(bitmap);
                                    String filename = "temp.jpeg";
                                    File sd = Environment.getExternalStorageDirectory();
                                    File dest = new File(sd, filename);

                                    Bitmap bitmap = (Bitmap) extras.get("data");
                                    try {
                                        FileOutputStream out = new FileOutputStream(dest);
                                        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
                                        out.flush();
                                        out.close();
                                        selectedImageUri = Uri.fromFile(dest);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                } else {
                                    selectedImageUri = result.getData().getData();
                                    try {
                                        bitmap = BitmapFactory.decodeStream(getBaseContext().
                                                getContentResolver().openInputStream(selectedImageUri));
                                        Picasso.get().load(selectedImageUri).placeholder(R.drawable.ic_baseline_person_24)
                                                .into(aadharimage);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
//                                Log.i("result--getresult code",""+result.getResultCode());

                                // set bitmap to image view here........
                            }
                        }
                    }
                });

        chooseimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectImage();
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressDialog.show();
//                Users user = new Users(name.getEditText().getText().toString(),
//                        email.getEditText().getText().toString(), password.getEditText().getText().toString());
                try {
                    storage.getReference().child("Aadhar_card")
                            .child(auth.getCurrentUser().getUid())
                            .putFile(selectedImageUri)
                            .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                    storage.getReference().child("Aadhar_card")
                                            .child(auth.getCurrentUser().getUid())
                                            .getDownloadUrl()
                                            .addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                @Override
                                                public void onSuccess(Uri uri) {
                                                    database.getReference().child("Aadharcard")
                                                            .child(auth.getCurrentUser().getUid())
                                                            .child("aadharcardlink").setValue(uri.toString());
                                                    Toast.makeText(Getaadharcard.this,
                                                            "Image Uploaded Successfully", Toast.LENGTH_SHORT).show();
                                                    progressDialog.dismiss();
                                                    startActivity(new Intent(Getaadharcard.this, Login_screen.class));
                                                    finish();
                                                }
                                            });
                                }
                            });
                } catch (Exception e) {

                }
            }
        });
    }

    private void selectImage() {
        final CharSequence[] options = {"Take Photo", "Choose from Gallery", "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(Getaadharcard.this);
        builder.setTitle("Add Photo!");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals("Take Photo")) {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    mTakePhoto.launch(intent);
//                    File f = new File(android.os.Environment.getExternalStorageDirectory(), "temp.jpg");
//                    intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(f));
//                    startActivityForResult(intent, 1);
                } else if (options[item].equals("Choose from Gallery")) {
                    Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    mTakePhoto.launch(intent);
//                    startActivityForResult(intent, 2);
                } else if (options[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }
}