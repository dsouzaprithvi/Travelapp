package com.example.vagabondapp.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;


import com.example.vagabondapp.R;
import com.example.vagabondapp.Viewprofile;
import com.example.vagabondapp.models.Locationmodel;
import com.example.vagabondapp.models.Users;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

import de.hdodenhof.circleimageview.CircleImageView;


public class MapsFragment extends Fragment implements OnMapReadyCallback {

    private GoogleMap mMap;

    TextInputLayout from, to, date;
    Button update;
    String totext, fromtext, tolattext, fromlattext;

    FirebaseAuth auth;
    FirebaseDatabase database;

    ArrayList<Users> userholder = new ArrayList<>();

    ArrayList<Locationmodel> locationholder = new ArrayList<>();

    String username, profilepic;

    public MapsFragment() {
        // Required empty public constructor
    }

    public static MapsFragment newInstance() {
        return new MapsFragment();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_maps, container, false);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager()
                .findFragmentById(R.id.google_maps);
        mapFragment.getMapAsync(this);

        from = view.findViewById(R.id.from);
        to = view.findViewById(R.id.to);
        update = view.findViewById(R.id.update);
        date = view.findViewById(R.id.date);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        MaterialDatePicker materialDatePicker = MaterialDatePicker.Builder.datePicker().
                setSelection(MaterialDatePicker.todayInUtcMilliseconds()).build();

        database.getReference().child("Users").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Users data = dataSnapshot.getValue(Users.class);
                    userholder.add(data);
                    if ( data.getId().equals(auth.getCurrentUser().getUid())) {
                        username = data.getUsername();
                        profilepic = data.getProfilepic();
                    }
//                    Log.i("User name --->", data.getUsername());
//                    Log.i("User id --->", data.getId());
//                            username.setText("abc");
//                            Picasso.get().load(data.getProfilepic()).placeholder(R.drawable.ic_baseline_person_24).into(profilepic);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        date.getEditText().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                materialDatePicker.show(getActivity().getSupportFragmentManager(), "Tag_picker");
                materialDatePicker.addOnPositiveButtonClickListener(new MaterialPickerOnPositiveButtonClickListener() {
                    @Override
                    public void onPositiveButtonClick(Object selection) {
                        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
                        calendar.setTimeInMillis((Long) selection);
                        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
                        String formattedDate = format.format(calendar.getTime());
                        date.getEditText().setText(formattedDate);
                    }
                });
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!validate_text(from) | !validate_text(to) | !validate_text(date)) {
                    return;
                }
                String fromtext = from.getEditText().getText().toString();
                String totext = to.getEditText().getText().toString();
                String locationfrom = getlocation(fromtext);
                String locationto = getlocation(totext);
                String datetext = date.getEditText().getText().toString();
                String id = auth.getCurrentUser().getUid();


                Log.i("Location--->>>", locationfrom);
                Log.i("Location2--->>", locationto);

                Locationmodel data = new Locationmodel(fromtext, totext, locationfrom, locationto, datetext, id, username, profilepic);
                database.getReference().child("Locations").child(id)
                        .child("Trip").setValue(data);
                Toast.makeText(getContext(), "Trip Updated successfully", Toast.LENGTH_SHORT).show();

            }

        });

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();


//        mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
//            @Override
//            public void onInfoWindowClick(@NonNull Marker marker) {
//
//            }
//        });
//        mMap.setInfoWindowAdapter(new TestInfoWindowAdapter(getActivity()));

        return view;
    }

    private String getlocation(String location) {
        String locationreturn = "";
        List<Address> addressList = null;
        if (location != null || location.equals("")) {
            // on below line we are creating and initializing a geo coder.
            Geocoder geocoder = new Geocoder(getContext());
            try {
                // on below line we are getting location from the
                // location name and adding that location to address list.
                addressList = geocoder.getFromLocationName(location, 1);
            } catch (IOException e) {
                e.printStackTrace();
            }
            // on below line we are getting the location
            // from our list a first position.
            Address address = addressList.get(0);

            // on below line we are creating a variable for our location
            // where we will add our locations latitude and longitude.
            LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());
            Log.i("locationfrom-->", latLng.toString());
            locationreturn = address.getLatitude() + "," + address.getLongitude();

        }
        return locationreturn;
    }

    private boolean validate_text(TextInputLayout id) {
        String val = id.getEditText().getText().toString().trim();
        if (val.isEmpty()) {
            id.setError("Field can not be empty");
            return false;
        } else {
            id.setError(null);
            id.setErrorEnabled(false);
            return true;
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        userholder.clear();



        database.getReference().child("Locations").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                locationholder.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    for (DataSnapshot child : dataSnapshot.getChildren()) {
                        Locationmodel location = child.getValue(Locationmodel.class);
                        locationholder.add(location);
                        if (location.getId().equals(auth.getCurrentUser().getUid())) {
                            from.getEditText().setText(location.getFrom());
                            to.getEditText().setText(location.getTo());
                            date.getEditText().setText(location.getDate());
                        }
//                        Toast.makeText(getContext(), locationholder.get(0).getLocationfrom(), Toast.LENGTH_SHORT).show();
                    }
                }
                displaymarker();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        // Add a marker in Sydney and move the camera
//            LatLng sydney = new LatLng(12.915294, 74.828736);
//            mMap.addMarker(new MarkerOptions().position(sydney).title("My location"));
//            float zoomLevel = 16.0f; //This goes up to 21
//            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney, zoomLevel));
//
//            TestInfoWindowAdapter testInfoWindowAdapter = new TestInfoWindowAdapter(this);
//            mMap.setInfoWindowAdapter(testInfoWindowAdapter);
//
//            ClickInfoWindowAdapter clickInfoWindowAdapter = new ClickInfoWindowAdapter(this);
//            mMap.setOnInfoWindowClickListener(clickInfoWindowAdapter);

//                mMap.setInfoWindowAdapter();
//        for (int i = 0; i < locationholder.size(); i++) {
//            Log.i("Location--->>>>>>>>", locationholder.get(i).getLocationfrom());
//            Toast.makeText(getContext(), "Location"+ locationholder.get(i).getLocationfrom(), Toast.LENGTH_SHORT).show();
//            String[] buffer = locationholder.get(i).getLocationfrom().split(",");
//            double lat = Double.parseDouble(buffer[0]);
//            double lng = Double.parseDouble(buffer[1]);
//            LatLng latLng = new LatLng(lat, lng);
//            mMap.addMarker(new MarkerOptions().position(latLng).title("My location"));
//            float zoomLevel = 16.0f; //This goes up to 21
//            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoomLevel));
//
//        }


    }

    private void displaymarker() {
        for (int i = 0; i < locationholder.size(); i++) {
//            Log.i("Location--->>>>>>>>", locationholder.get(i).getLocationfrom());
            String[] buffer = locationholder.get(i).getLocationfrom().split(",");
            double lat = Double.parseDouble(buffer[0]);
            double lng = Double.parseDouble(buffer[1]);
            LatLng latLng = new LatLng(lat, lng);
            Marker marker =  mMap.addMarker(new MarkerOptions().position(latLng).title("My location"));
            Locationmodel locationmodel = locationholder.get(i);
            marker.setTag(locationmodel);
            float zoomLevel = 12f; //This goes up to 21
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoomLevel));

            TestInfoWindowAdapter testInfoWindowAdapter = new TestInfoWindowAdapter(this);
            mMap.setInfoWindowAdapter(testInfoWindowAdapter);

            ClickInfoWindowAdapter clickInfoWindowAdapter = new ClickInfoWindowAdapter(this);
            mMap.setOnInfoWindowClickListener(clickInfoWindowAdapter);

//            Log.i("User id----------->", userholder.get(i).getId());

//            for (int j = 0; j < userholder.size(); j++) {
//                if (userholder.get(j).equals(locationholder.get(i).getId())) {
//                    Users user = userholder.get(j);
//                    Log.i("User id----------->", user.getId());
//
////                    Picasso.get().load(user.getProfilepic()).placeholder(R.drawable.ic_baseline_person_24).into(profilepic);
//                }
//            }



        }
    }

    private class ClickInfoWindowAdapter implements GoogleMap.OnInfoWindowClickListener {

        private MapsFragment context;
        private int i;

        public ClickInfoWindowAdapter(MapsFragment context) {
            this.context = context;
//            this.i = i;
        }

        @Override
        public void onInfoWindowClick(@NonNull Marker marker) {
//            Toast.makeText(getContext(), "HFSifosfs", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getContext(), Viewprofile.class);
            Locationmodel locationmodel = (Locationmodel) marker.getTag();
            intent.putExtra("Userid", locationmodel.getId());
            startActivity(intent);
        }
    }

    private class TestInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {

        private MapsFragment context;
        private int i;

        public TestInfoWindowAdapter(MapsFragment context) {
            this.context = context;
//            this.i = i;

        }

        @Nullable
        @Override
        public View getInfoContents(@NonNull Marker marker) {
            return null;
        }

        @Nullable
        @Override
        public View getInfoWindow(@NonNull Marker marker) {
            View view = context.getLayoutInflater().inflate(R.layout.info_popup, null);

            CircleImageView profilepic;
            TextView username;
//            ImageButton chat;

            profilepic = view.findViewById(R.id.profilepic);
            username = view.findViewById(R.id.username);
            Locationmodel locationmodel = (Locationmodel) marker.getTag();
            username.setText(locationmodel.getUsername());
            Picasso.get().load(locationmodel.getProfilepic()).placeholder(R.drawable.ic_baseline_person_24).into(profilepic);
//            Log.i("Sidnwidwiqd-----....", locationmodel.getId());
//            setcontents(profilepic, username, locationmodel);
//            chat = view.findViewById(R.id.chat);
//            username.setText("abc");


//            username.setText(locationmodel.getId());

//            Users users = (Users) marker.getTag();
//            username.setText(users.getUsername());


            return view;
        }
    }

    private void setcontents(CircleImageView profile,TextView username , Locationmodel locationmodel) {

        for (int i = 0 ; i < userholder.size(); i++) {
            if ( userholder.get(i).equals(locationmodel.getId())) {
                Users user = userholder.get(i);
                username.setText(user.getUsername());
            }
        }

//        for (int i = 0; i < locationholder.size(); i++) {
//            for (int j = 0; j < userholder.size(); j++) {
//                Users user = userholder.get(j);
//                if (locationholder.get(i).getId().equals(user.getId())) {
//                    Log.i("Sidnwidwiqd-----....", user.getUsername());
//                    username.setText(user.getUsername());
//                    if (user.getId().equals(auth.getCurrentUser().getUid())) {
////                        username.setText(user.getUsername());
//                        Log.i("Sidnwidwiqd-----....", locationholder.get(i).getId());
////                        Picasso.get().load(user.getProfilepic()).placeholder(R.drawable.ic_baseline_person_24).into(profilepic);
//                    }
//                }
//            }


    }
}


//    @Override
//    public void onInfoWindowClick(@NonNull Marker marker) {
//
//    }
//
//    @Override
//    public void onMapReady(@NonNull GoogleMap googleMap) {
//        mMap = googleMap;
//
//        // Add a marker in Sydney and move the camera
//        LatLng sydney = new LatLng(12.915294, 74.828736);
//        mMap.addMarker(new MarkerOptions().position(sydney).title("My location"));
//        float zoomLevel = 16.0f; //This goes up to 21
//        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney, zoomLevel));
//        mMap.setOnInfoWindowClickListener(this);
//    }
//
//    @Override
//    public void onClick(View view) {
//
//    }
//

//    private class TestInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {
//
//        private Context context;
//
//        public TestInfoWindowAdapter(Context context) {
//            this.context = context;
//        }
//
//        @Nullable
//        @Override
//        public View getInfoContents(@NonNull Marker marker) {
//            return null;
//        }
//
//        @Nullable
//        @Override
//        public View getInfoWindow(@NonNull Marker marker) {
//
//            View view = ((Activity)context).getLayoutInflater().inflate(R.layout.info_popup, null);
//
//            TextView username = view.findViewById(R.id.username);
//            CircleImageView profilepic = view.findViewById(R.id.profilepic);
//            Button chat = view.findViewById(R.id.chat);
//
//
//            return view;
//        }
//    }
