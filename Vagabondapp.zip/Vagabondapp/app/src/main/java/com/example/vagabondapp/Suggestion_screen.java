package com.example.vagabondapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Suggestion_screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggestion_screen);
    }
}