package com.example.vagabondapp;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Interpolator;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.vagabondapp.models.Users;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import de.hdodenhof.circleimageview.CircleImageView;

public class Edituserprofile extends AppCompatActivity {

    TextInputLayout name, email, password;
    CircleImageView profilepic;
    FloatingActionButton chooseimage;
    MaterialButton update;
    ProgressDialog progressDialog;

    FirebaseAuth auth;
    FirebaseDatabase database;
    FirebaseStorage storage;

    ActivityResultLauncher mTakePhoto;
    Uri selectedImageUri;
    Bitmap bitmap;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edituserprofile);

        name = findViewById(R.id.full_name);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        profilepic = findViewById(R.id.profile_pic);
        chooseimage = findViewById(R.id.updateprofilepic);
        update = findViewById(R.id.update);

        progressDialog = new ProgressDialog(Edituserprofile.this);
        progressDialog.setTitle("Updating Details");


        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        storage = FirebaseStorage.getInstance();

        String id = auth.getCurrentUser().getUid();

        database.getReference().child("Users").child(id).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Users user = snapshot.getValue(Users.class);
                name.getEditText().setText(user.getUsername());
                email.getEditText().setText(user.getMail());
                password.getEditText().setText(user.getPassword());
                Picasso.get().load(user.getProfilepic()).placeholder(R.drawable.ic_baseline_person_24).into(profilepic);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Edituserprofile.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        mTakePhoto = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            if (result.getData() != null ) {
                                Bundle extras = result.getData().getExtras();
                                if (extras != null) {
                                    bitmap = (Bitmap) extras.get("data");
                                    profilepic.setImageBitmap(bitmap);
                                    String filename = "temp.jpeg";
                                    File sd = Environment.getExternalStorageDirectory();
                                    File dest = new File(sd, filename);

                                    Bitmap bitmap = (Bitmap) extras.get("data");
                                    try {
                                        FileOutputStream out = new FileOutputStream(dest);
                                        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
                                        out.flush();
                                        out.close();
                                        selectedImageUri = Uri.fromFile(dest);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
//                                    Uri filepath = Uri.fromFile(file);

                                } else {
                                    selectedImageUri = result.getData().getData();
                                    try {
                                        bitmap = BitmapFactory.decodeStream(getBaseContext()
                                                .getContentResolver()
                                                .openInputStream(selectedImageUri));
                                        Picasso.get().load(selectedImageUri)
                                                .placeholder(R.drawable.ic_baseline_person_24)
                                                .into(profilepic);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
//                                Log.i("result--getresult code",""+result.getResultCode());

                                // set bitmap to image view here........
                            }
                        }
                    }
                });

        chooseimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//                mTakePhoto.launch(intent);
                selectImage();
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressDialog.show();
                Users user = new Users(name.getEditText().getText().toString(),
                        email.getEditText().getText().toString(), password.getEditText().getText().toString());
                try {
                    storage.getReference().child("Profile_pictures")
                            .child(auth.getCurrentUser().getUid())
                            .putFile(selectedImageUri)
                            .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                    storage.getReference().child("Profile_pictures")
                                            .child(auth.getCurrentUser().getUid())
                                            .getDownloadUrl()
                                            .addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                @Override
                                                public void onSuccess(Uri uri) {
                                                    database.getReference().child("Users")
                                                            .child(auth.getCurrentUser().getUid())
                                                            .child("profilepic").setValue(uri.toString());
                                                    Toast.makeText(Edituserprofile.this,
                                                            "Image Uploaded Successfully", Toast.LENGTH_SHORT).show();
                                                    progressDialog.dismiss();
                                                }
                                            });
                                }
                            });
                } catch (Exception e) {
                    progressDialog.dismiss();
                }
//                database.getReference().child("Users/"+auth.getCurrentUser().getUid()+"/username")
//                        .setValue(user.getUsername());
//                database.getReference().child("Users/"+auth.getCurrentUser().getUid()+"/mail")
//                        .setValue(user.getMail());
//                database.getReference().child("Users/"+auth.getCurrentUser().getUid()+"/password")
//                        .setValue(user.getPassword());
//                auth.getCurrentUser().updateEmail(user.getMail()).addOnCompleteListener(new OnCompleteListener<Void>() {
//                    @Override
//                    public void onComplete(@NonNull Task<Void> task) {
//                        if (task.isSuccessful()){
//
//                        }
//                    }
//                });
//                auth.getCurrentUser().updatePassword(user.getMail()).addOnCompleteListener(new OnCompleteListener<Void>() {
//                    @Override
//                    public void onComplete(@NonNull Task<Void> task) {
//                        if (task.isSuccessful()){
//                            Toast.makeText(Edituserprofile.this, "Update Successful"
//                                    , Toast.LENGTH_SHORT).show();
//                        }
//                    }
//                });



            }
        });


    }


    private void selectImage() {
        final CharSequence[] options = {"Take Photo", "Choose from Gallery", "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(Edituserprofile.this);
        builder.setTitle("Add Photo!");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals("Take Photo")) {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//                    File f = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "temp.jpg");
//                    intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(f));
                    mTakePhoto.launch(intent);
//                    startActivityForResult(intent, 1);
                } else if (options[item].equals("Choose from Gallery")) {
                    Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    mTakePhoto.launch(intent);
//                    startActivityForResult(intent, 2);
                } else if (options[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }
}