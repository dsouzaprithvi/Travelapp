package com.example.vagabondapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.vagabondapp.models.Users;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class Viewprofile extends AppCompatActivity {

    TextView username, email;
    Button chat;
    CircleImageView profilepic;

    FirebaseAuth auth;
    FirebaseDatabase database;

    Users data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewprofile);

        username = findViewById(R.id.user_name);
        email = findViewById(R.id.email);
        profilepic = findViewById(R.id.profile_pic);
        chat = findViewById(R.id.chat);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        String id = getIntent().getStringExtra("Userid");

        database.getReference().child("Users/"+id).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                data = snapshot.getValue(Users.class);
                username.setText(data.getUsername());
                email.setText(data.getMail());
                Picasso.get().load(data.getProfilepic()).placeholder(R.drawable.ic_baseline_person_24).into(profilepic);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Viewprofile.this, Chat_screen.class);
                intent.putExtra("Username", data.getUsername());
                intent.putExtra("Userid", data.getId());
                startActivity(intent);
            }
        });
    }
}