package com.example.vagabondapp.models;

public class Locationmodel {

    String from , to , locationfrom, locationto, date, id, username, profilepic;

    public Locationmodel() {
    }

    public Locationmodel(String from, String to, String locationfrom, String locationto, String date, String id, String username, String profilepic) {
        this.from = from;
        this.to = to;
        this.locationfrom = locationfrom;
        this.locationto = locationto;
        this.date = date;
        this.id = id;
        this.username = username;
        this.profilepic = profilepic;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getLocationfrom() {
        return locationfrom;
    }

    public void setLocationfrom(String locationfrom) {
        this.locationfrom = locationfrom;
    }

    public String getLocationto() {
        return locationto;
    }

    public void setLocationto(String locationto) {
        this.locationto = locationto;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getProfilepic() {
        return profilepic;
    }

    public void setProfilepic(String profilepic) {
        this.profilepic = profilepic;
    }
}
