package com.example.vagabondapp.adpters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.vagabondapp.Chat_screen;
import com.example.vagabondapp.R;
import com.example.vagabondapp.models.Users;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class UsersAdapter extends RecyclerView.Adapter<UsersAdapter.MyViewholder>{

    Context context;
    ArrayList<Users> usersholder;

    public UsersAdapter(Context context, ArrayList<Users> usersholder) {
        this.context = context;
        this.usersholder = usersholder;
    }

    @NonNull
    @Override
    public MyViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_row_chat, parent, false);
        return new MyViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewholder holder, int position) {

        Users data = usersholder.get(position);

        Picasso.get().load(data.getProfilepic()).placeholder(R.drawable.ic_baseline_person_24).into(holder.profilepic);

        holder.name.setText(data.getUsername());
        holder.lastmessage.setText(data.getLastmessage());
        holder.date.setText(data.getDate());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(new Intent(context, Chat_screen.class));
                intent.putExtra("Username", data.getUsername());
                intent.putExtra("Userid", data.getId());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return usersholder.size();
    }

    public class MyViewholder extends RecyclerView.ViewHolder {

        ImageView profilepic;
        TextView name, lastmessage, date;

        public MyViewholder(@NonNull View itemView) {
            super(itemView);

            profilepic = itemView.findViewById(R.id.profile_pic);
            name = itemView.findViewById(R.id.user_name);
            lastmessage = itemView.findViewById(R.id.last_message);
            date = itemView.findViewById(R.id.date);
        }
    }
}
