package com.example.vagabondapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class Login_screen extends AppCompatActivity {

    TextInputLayout mail, password;
    Button login;
    TextView signup;
    ProgressDialog progressDialog;
    FirebaseAuth auth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);

        login = findViewById(R.id.login);
        signup = findViewById(R.id.signup);
        mail = findViewById(R.id.email);
        password = findViewById(R.id.password);


        progressDialog = new ProgressDialog(Login_screen.this);
        progressDialog.setTitle("Log In");
        progressDialog.setMessage("Logging in to your account");

        auth = FirebaseAuth.getInstance();


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!validate_text(mail) | !validate_text(password)){
                    return;
                }

                progressDialog.show();
                String uname = mail.getEditText().getText().toString();
                String upass = password.getEditText().getText().toString();

                auth.signInWithEmailAndPassword(uname, upass)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                progressDialog.dismiss();
                                if (task.isSuccessful()) {
                                    startActivity(new Intent(Login_screen.this, MainActivity.class));
                                    finish();
                                }else {
                                    Toast.makeText(Login_screen.this, task.getException().getMessage(),
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Login_screen.this, Signup_screen.class));
            }
        });


        if(auth.getCurrentUser()!=null){
            Intent intent = new Intent(Login_screen.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
    }

    private boolean validate_text(TextInputLayout id) {
        String val = id.getEditText().getText().toString().trim();
        if (val.isEmpty()) {
            id.setError("Field can not be empty");
            return false;
        } else {
            id.setError(null);
            id.setErrorEnabled(false);
            return true;
        }
    }
}