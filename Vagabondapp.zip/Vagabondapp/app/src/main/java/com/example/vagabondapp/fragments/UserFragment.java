package com.example.vagabondapp.fragments;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.vagabondapp.R;
import com.example.vagabondapp.Splash_screen;
import com.example.vagabondapp.models.Users;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class UserFragment extends Fragment {

    TextView logout, username, email;
    FirebaseAuth auth;
    FirebaseDatabase database;
    Users user;
    ProgressDialog progressDialog;

    public UserFragment() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_user, container, false);

        logout = view.findViewById(R.id.logout);
        username = view.findViewById(R.id.user_name);
        email = view.findViewById(R.id.email);

        progressDialog = new ProgressDialog(getContext());
        progressDialog.setTitle("Loading Details");
        progressDialog.show();

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        String id = auth.getCurrentUser().getUid();
        Log.i("Users---->>>", id);
        database.getReference().child("Users").child(id).
                addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        progressDialog.dismiss();
                        user = snapshot.getValue(Users.class);
                        username.setText(user.getUsername());
                        email.setText(user.getMail());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                auth.signOut();
                startActivity(new Intent(getContext(), Splash_screen.class));
                getActivity().finish();
            }
        });

        return view;
    }
}