package com.example.vagabondapp.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;


import com.example.vagabondapp.R;
import com.google.android.material.textfield.TextInputLayout;


public class HomeFragment extends Fragment {

    TextInputLayout from ,to;
    Button update;

    public HomeFragment() {
        // Required empty public constructor
    }

    

   

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_home, container, false);

        Fragment fragment = new MapsFragment();
        getChildFragmentManager().beginTransaction().replace(R.id.frame_layout, fragment).commit();


//        from = view.findViewById(R.id.from);
//        to = view.findViewById(R.id.to);
//        update = view.findViewById(R.id.update);
//
//        update.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if( !validate_text(from) | !validate_text(to) ) {
//                    return;
//                }
//            }
//        });


        return view;
    }

    private boolean validate_text(TextInputLayout id) {
        String val = id.getEditText().getText().toString().trim();
        if (val.isEmpty()) {
            id.setError("Field can not be empty");
            return false;
        } else {
            id.setError(null);
            id.setErrorEnabled(false);
            return true;
        }
    }
}