package com.example.travelapp.models;

public class Recentchatmodel {

}
