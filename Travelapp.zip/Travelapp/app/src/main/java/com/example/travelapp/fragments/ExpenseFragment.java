package com.example.travelapp.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.travelapp.Addtranscation;
import com.example.travelapp.R;
import com.example.travelapp.adpters.TransactionAdapter;
import com.example.travelapp.models.TranscationModel;

import java.util.ArrayList;


public class ExpenseFragment extends Fragment {

    Button addtransaction;

    ArrayList<TranscationModel> transcationholder;
    TransactionAdapter adapter;
    RecyclerView recyclerView;


    public ExpenseFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_expense, container, false);

        addtransaction = view.findViewById(R.id.add_transaction);

        TranscationModel obj = new TranscationModel("500","12","salary","income", "12-12-2021");

        transcationholder = new ArrayList<>();
        transcationholder.add(obj);
        adapter = new TransactionAdapter(getContext(), transcationholder);


        recyclerView = view.findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);




        addtransaction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), Addtranscation.class));
            }
        });


        return view;
    }
}