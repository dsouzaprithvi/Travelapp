package com.example.travelapp.adpters;

public class Recentchatadapter {
}
