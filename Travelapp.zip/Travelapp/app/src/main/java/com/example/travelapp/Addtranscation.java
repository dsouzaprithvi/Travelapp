package com.example.travelapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.travelapp.models.TranscationModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Addtranscation extends AppCompatActivity {

    CheckBox incomebox, expensebox;
    Button add;
    EditText amount, note;

    String amountstring, notestring, type;


    FirebaseAuth auth;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addtranscation);


        incomebox = findViewById(R.id.income_check_box);
        expensebox = findViewById(R.id.expense_check_box);
        add = findViewById(R.id.add);
        amount = findViewById(R.id.amount);
        note = findViewById(R.id.note);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        incomebox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                type = "income";
                incomebox.setChecked(true);
                expensebox.setChecked(false);
            }
        });

        expensebox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                type = "expense";
                incomebox.setChecked(false);
                expensebox.setChecked(true);
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!validate(amount) | !validate(note)) {
                    return;
                }
                if ( type.length() <= 0 ) {
                    Toast.makeText(Addtranscation.this, "Select Transaction type",
                            Toast.LENGTH_SHORT).show();
                }

//                amountstring = amount.getText().toString();
//                notestring = note.getText().toString();
//                String id = auth.getCurrentUser().getUid();
//                String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
//
//                TranscationModel transcationModel = new TranscationModel()
//
//                database.getReference().child("Transactions").child(id).setValue()

            }
        });

    }

    private boolean validate(EditText id){
        String val = id.getText().toString().trim();
        if (val.isEmpty()) {
            Toast.makeText(Addtranscation.this, "Field cannot be empty",
                    Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }
    }
}