package com.example.travelapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class Splash_screen extends AppCompatActivity {


    public static int SPLASH_SCREEN = 4000;
    ImageView logoimage;
    Animation topanim, bottomanim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        //Animations
        topanim = AnimationUtils.loadAnimation(this, R.anim.top_animation);
        bottomanim = AnimationUtils.loadAnimation(this, R.anim.bottom_animation);

        logoimage = findViewById(R.id.logo);
        logoimage.setAnimation(topanim);

        new Handler().postDelayed(() -> {

            Intent intent = new Intent(Splash_screen.this, Login_screen.class);
            startActivity(intent);
            finish();

        },SPLASH_SCREEN);
    }
}