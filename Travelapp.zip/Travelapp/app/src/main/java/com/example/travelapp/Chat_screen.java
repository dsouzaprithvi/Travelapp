package com.example.travelapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Chat_screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_screen);
    }
}