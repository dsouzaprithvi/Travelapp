package com.example.travelapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.travelapp.adpters.Chatadapter;
import com.example.travelapp.models.Messagesmodel;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Date;

public class Chat_screen extends AppCompatActivity {

    TextView username;
    EditText etmessage;
    MaterialButton back;
    FirebaseAuth auth;
    FirebaseDatabase database;
    FloatingActionButton send;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_screen);


        username = findViewById(R.id.username);
        back = findViewById(R.id.back);
        send = findViewById(R.id.send);
        etmessage = findViewById(R.id.etMessage);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        String senderid = auth.getCurrentUser().getUid();
        String receiverid = getIntent().getStringExtra("Userid");


        username.setText(getIntent().getStringExtra("Username"));

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        final ArrayList<Messagesmodel> messagesholder = new ArrayList<>();

        final Chatadapter chatadapter = new Chatadapter(messagesholder, this);

        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setAdapter(chatadapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        final String senderroom = senderid + receiverid;
        final String receiverroom = receiverid + senderid;


        database.getReference().child("Chats")
                .child(senderroom)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        messagesholder.clear();

                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Messagesmodel model = dataSnapshot.getValue(Messagesmodel.class);
                            messagesholder.add(model);
                        }

                        chatadapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String message = etmessage.getText().toString();
                final Messagesmodel model = new Messagesmodel(senderid, message);
                model.setTimestamp(new Date().getTime());
                etmessage.setText("");


                database.getReference().child("Chats")
                        .child(senderroom)
                        .push()
                        .setValue(model).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                database.getReference().child("Chats")
                                        .child(receiverroom)
                                        .push()
                                        .setValue(model).addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void unused) {

                                            }
                                        });
                            }
                        });
            }
        });




    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}