package com.example.travelapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import com.example.travelapp.models.Users;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class Signup_screen extends AppCompatActivity {


    Button signup;
    ProgressDialog progressDialog;
    TextInputLayout firstname, lastname, mail, password, confirmpassword;
    FirebaseAuth auth;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_screen);

        signup = findViewById(R.id.signup);
        firstname = findViewById(R.id.first_name);
        lastname = findViewById(R.id.last_name);
        mail = findViewById(R.id.email);
        password = findViewById(R.id.password);
        confirmpassword = findViewById(R.id.confirm_password);


        progressDialog = new ProgressDialog(Signup_screen.this);
        progressDialog.setTitle("Creating Account");
        progressDialog.setMessage("We are creating your account");

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        signup.setOnClickListener(view -> {
            if (!validate_text(firstname) | !validate_text(lastname) |
                    !validate_text(password) | !validate_text(confirmpassword) |
                    !validate_text(mail)) {
                return;
            }

            if (!validate_password()){
                return;
            }


            progressDialog.show();
            String name = firstname.getEditText().getText().toString() + " " +
                    lastname.getEditText().getText().toString();
            String email = mail.getEditText().getText().toString();
            String pass = password.getEditText().getText().toString();
            String id = auth.getCurrentUser().getUid();
            auth.createUserWithEmailAndPassword(email, pass)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    progressDialog.dismiss();
                    if (task.isSuccessful()){
                        Users user = new Users(name, email, pass, id);
                        String id = task.getResult().getUser().getUid();
                        database.getReference().child("Users").child(id).setValue(user);
                        startActivity(new Intent(Signup_screen.this, Signupsuccessfull.class));

                    }else{
                        Toast.makeText(Signup_screen.this, task.getException().getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
            });
        });
    }

    private boolean validate_text(TextInputLayout id) {
        String val = id.getEditText().getText().toString().trim();
        if (val.isEmpty()) {
            id.setError("Field can not be empty");
            return false;
        } else {
            id.setError(null);
            id.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validate_password(){
        String pass = password.getEditText().getText().toString();
        String cpass = confirmpassword.getEditText().getText().toString();
        if (pass.equals(cpass)){
            confirmpassword.setError(null);
            confirmpassword.setErrorEnabled(false);
            return true;
        } else {
            confirmpassword.setError("Password does not match");
            return false;
        }
    }

}