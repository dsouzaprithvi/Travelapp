package com.example.travelapp.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.travelapp.R;
import com.example.travelapp.User_screen;
import com.example.travelapp.adpters.UsersAdapter;
import com.example.travelapp.models.Users;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class ChatFragment extends Fragment {




    FirebaseAuth auth;
    FirebaseDatabase database;

    ArrayList<Users> usersholder;
    UsersAdapter adapter;
    RecyclerView recyclerView;



    public ChatFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_chat, container, false);

        recyclerView = view.findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        usersholder = new ArrayList<>();
        adapter = new UsersAdapter(getContext(), usersholder);
        recyclerView.setAdapter(adapter);

        loaddata();


//        FloatingActionButton users = view.findViewById(R.id.users);
//        users.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getContext(), User_screen.class));
//            }
//        });

        return view;
    }

    private void loaddata () {

        String id = auth.getCurrentUser().getUid();

        database.getReference().child("Users").
                addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        usersholder.clear();
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Users obj = dataSnapshot.getValue(Users.class);
                            if (obj.getId().equals(id)) {
                                continue;
                            } else {
                                usersholder.add(obj);
                            }




                        }
                        Collections.sort(usersholder, new Comparator<Users>() {
                            @Override
                            public int compare(Users users, Users t1) {
                                return users.getUsername().compareToIgnoreCase(t1.getUsername());
                            }
                        });

                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

    }




}