package com.example.travelapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.example.travelapp.fragments.ChatFragment;
import com.example.travelapp.fragments.ExpenseFragment;
import com.example.travelapp.fragments.HomeFragment;
import com.example.travelapp.fragments.SuggestionFragment;
import com.example.travelapp.fragments.UserFragment;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {


    private DrawerLayout drawer;
    ActionBarDrawerToggle toggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        drawer = findViewById(R.id.drawer_layout);

        toggle = new ActionBarDrawerToggle(MainActivity.this,
                drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                new HomeFragment()).commit();
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        Fragment selected_fragment = null;
        switch (item.getItemId()) {
            case R.id.homepage:
                selected_fragment = new HomeFragment();
                drawer.close();
                toggle.syncState();
                break;
            case R.id.suggestions:
                selected_fragment = new SuggestionFragment();
                drawer.close();
                toggle.syncState();
                break;
            case R.id.chat:
                selected_fragment = new ChatFragment();
                drawer.close();
                toggle.syncState();
                break;
            case R.id.expense_tracker:
                selected_fragment = new ExpenseFragment();
                drawer.close();
                toggle.syncState();
                break;
            case R.id.user_profile:
                selected_fragment = new UserFragment();
                drawer.close();
                toggle.syncState();
                break;
        }

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                selected_fragment).commit();
        return true;
    }




    @Override
    public void onBackPressed() {
        if(drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        }
        else{
            super.onBackPressed();
        }
    }
}