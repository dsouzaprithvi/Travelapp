package com.example.travelapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.example.travelapp.fragments.ChatFragment;
import com.example.travelapp.fragments.ExpenseFragment;
import com.example.travelapp.fragments.HomeFragment;
import com.example.travelapp.fragments.SuggestionFragment;
import com.example.travelapp.fragments.UserFragment;
import com.example.travelapp.models.Users;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {


    private DrawerLayout drawer;
    ActionBarDrawerToggle toggle;
    Users user;
    TextView username, email;
    FirebaseAuth auth;
    FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        drawer = findViewById(R.id.drawer_layout);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        toggle = new ActionBarDrawerToggle(MainActivity.this,
                drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        View headerview = navigationView.getHeaderView(0);
        TextView username = headerview.findViewById(R.id.user_name);
        TextView email = headerview.findViewById(R.id.email);
        navigationView.setNavigationItemSelectedListener(this);


        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                new HomeFragment()).commit();

        String id = auth.getCurrentUser().getUid();

        database.getReference().child("Users").child(id).
                addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        user = snapshot.getValue(Users.class);
                        username.setText(user.getUsername());
                        email.setText(user.getMail());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        Fragment selected_fragment = null;
        switch (item.getItemId()) {
            case R.id.homepage:
                selected_fragment = new HomeFragment();
                drawer.close();
                toggle.syncState();
                break;
            case R.id.suggestions:
                selected_fragment = new SuggestionFragment();
                drawer.close();
                toggle.syncState();
                break;
            case R.id.chat:
                selected_fragment = new ChatFragment();
                drawer.close();
                toggle.syncState();
                break;
            case R.id.expense_tracker:
                selected_fragment = new ExpenseFragment();
                drawer.close();
                toggle.syncState();
                break;
            case R.id.user_profile:
                selected_fragment = new UserFragment();
                drawer.close();
                toggle.syncState();
                break;
        }

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                selected_fragment).commit();
        return true;
    }





    @Override
    public void onBackPressed() {
        if(drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        }
        else{
            super.onBackPressed();
        }
    }
}